# Obsidian Vault Agent Dashboard Case

**Repository:** OpenMinis/AwesomeMinis  
**PR:** #11  
**Case:** Agent-Run Obsidian Vault (Minis + Agentic Dashboard)

## Productivity & Automation Table Row

| Case | Description | Status |
|------|-------------|--------|
| Agent-Run Obsidian Vault | Minis writes tasks/captures/meetings → Agentic Dashboard renders live dashboard | Draft |

## Minis Skills

- `plugin-command-tester` - Systematic verification of Obsidian Agentic Dashboard plugin commands
- `obsidian-agentic-dashboard` - Trigger actions via `obsidian://agentic-dashboard?op=...` URIs

## Minis Agent Testing Workflow

1. Open Minis app to background Obsidian: `apple-open "minis://open_terminal"`
2. Execute `obsidian://agentic-dashboard?op=...` URI
3. Verify vault `.md` file changes (critical - don't rely on `opened` field)
4. Document: exact URI, `opened` field, file location, note name

## iOS Foregrounding Limitation

- When Obsidian is foregrounded: `apple-open` returns `opened: false`
- **Rule:** Background Obsidian via Minis first → all URIs execute immediately (`opened: true`)
- No 2-minute wait needed if Minis was opened beforehand

## Vault Mounting

- **Test vault:** `/var/minis/mounts/Plugin testing vault/`
- **Reference vault:** `/var/minis/mounts/Agents board/`
- **General mount:** `/var/minis/mounts/<name>/`

## Submission Requirements

1. **Screenshots** (7+): Minis vault mounting, plugin manifest, command execution, vault .md changes, mounting settings
2. **Bilingual format**: Chinese/English paragraph alternation
3. **Mount path**: `/var/minis/mounts/<name>/`

## Reference

- **PR #11:** https://github.com/OpenMinis/AwesomeMinis/pull/11
- **Testing skill:** `plugin-command-tester` (updated with single rule)
- **Dashboard skill:** `obsidian-agentic-dashboard` (updated with single rule)